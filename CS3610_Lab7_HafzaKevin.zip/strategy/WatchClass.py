from I_InteractClass import I_Interact

class Watch(I_Interact):
    def interact(self):
        print("Watching a movie!")

