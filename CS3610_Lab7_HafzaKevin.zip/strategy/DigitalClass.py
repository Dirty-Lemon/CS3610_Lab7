
from ITypeClass import I_Type

class Digital(I_Type):
    def buy(self):
        print("Buying a digital copy")

