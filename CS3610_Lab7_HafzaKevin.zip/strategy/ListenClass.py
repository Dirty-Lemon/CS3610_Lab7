from I_InteractClass import I_Interact

class Listen(I_Interact):
    def interact(self):
        print("Listening to music!")   