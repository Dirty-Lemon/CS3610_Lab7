
from IGenreClass import IGenre
        
class Non_Fiction(IGenre):
    def genreType(self):
        print("Genre is Non-Fiction entertainment")