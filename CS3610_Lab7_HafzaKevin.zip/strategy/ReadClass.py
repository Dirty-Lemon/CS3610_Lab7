
from I_InteractClass import I_Interact

class Read(I_Interact):
    def interact(self):
        print("Reading a book!")

