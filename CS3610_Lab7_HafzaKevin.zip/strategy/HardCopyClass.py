
from ITypeClass import I_Type
class HardCopy(I_Type):
    def buy(self):
        print("Buying a hard-copy")