
from IGenreClass import IGenre

class Fiction(IGenre):
    def genreType(self):
        print("Genre is Fiction entertainment")

      